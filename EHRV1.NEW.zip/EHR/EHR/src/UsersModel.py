from Constants import connString
import pyodbc
import uuid


class UsersModel:
    def __init__(self, userID=0, userName='', emailid='', password='', contactNo='', isActive=False, roleID=0,
                 roleModel=None, aadharNumber: str = ''):
        self.userID = userID
        self.userName = userName
        self.emailid = emailid
        self.password = password
        self.contactNo = contactNo
        self.isActive = isActive
        self.roleID = roleID
        self.roleModel = roleModel
        self.aadharNumber = aadharNumber

    @staticmethod
    def get_all():
        conn = pyodbc.connect(connString, autocommit=True)
        cursor = conn.cursor()
        sqlcmd1 = "SELECT * FROM Users ORDER BY userName"
        cursor.execute(sqlcmd1)
        records = []
        for dbrow in cursor.fetchall():
            row = UsersModel(dbrow.userID, dbrow.userName, dbrow.emailid, dbrow.password, dbrow.contactNo,
                             dbrow.isActive, dbrow.roleID, aadharNumber=dbrow.aadharNumber)
            records.append(row)
        cursor.close()
        conn.close()
        return records

    @staticmethod
    def get_name_id():
        conn = pyodbc.connect(connString, autocommit=True)
        cursor = conn.cursor()
        sqlcmd1 = "SELECT userID, userName FROM Users ORDER BY userName"
        cursor.execute(sqlcmd1)
        records = []
        for dbrow in cursor.fetchall():
            row = UsersModel(dbrow.userID, dbrow.userName)
            records.append(row)
        cursor.close()
        conn.close()
        return records

    @staticmethod
    def get_by_id(unique_id):
        conn = pyodbc.connect(connString, autocommit=True)
        cursor = conn.cursor()
        sqlcmd1 = "SELECT * FROM Users WHERE userID = ?"
        cursor.execute(sqlcmd1, unique_id)
        record = None
        for dbrow in cursor.fetchall():
            record = UsersModel(dbrow.userID, dbrow.userName, dbrow.emailid, dbrow.password, dbrow.contactNo,
                                dbrow.isActive, dbrow.roleID, aadharNumber=dbrow.aadharNumber)
        cursor.close()
        conn.close()
        return record

    @staticmethod
    def insert(obj):
        obj.userID = str(uuid.uuid4())
        conn = pyodbc.connect(connString, autocommit=True)
        cursor = conn.cursor()
        sqlcmd1 = "INSERT INTO Users (userName,emailid,password,contactNo,isActive,roleID, aadharNumber) VALUES(?,?,?,?,?,?,?)"
        cursor.execute(sqlcmd1, (
        obj.userName, obj.emailid, obj.password, obj.contactNo, obj.isActive, obj.roleID, obj.aadharNumber))
        cursor.close()
        conn.close()

    @staticmethod
    def update(obj):
        conn = pyodbc.connect(connString, autocommit=True)
        cursor = conn.cursor()
        sqlcmd1 = "UPDATE Users SET userName = ?,emailid = ?,password = ?,contactNo = ?,isActive = ?,roleID = ?, aadharNumber = ? WHERE " \
                  "userID = ? "
        cursor.execute(sqlcmd1,
                       (obj.userName, obj.emailid, obj.password, obj.contactNo, obj.isActive, obj.roleID,
                        obj.aadharNumber, obj.userID))
        cursor.close()
        conn.close()

    @staticmethod
    def delete(unique_id):
        conn = pyodbc.connect(connString, autocommit=True)
        cursor = conn.cursor()
        sqlcmd1 = "DELETE FROM Users WHERE userID = ?"
        cursor.execute(sqlcmd1, unique_id)
        cursor.close()
        conn.close()
