const Patients = artifacts.require("PatientsContract.sol");
        module.exports = function (deployer) {
          deployer.deploy(Patients);
        };
        