const EHRRecords = artifacts.require("EHRRecordsContract.sol");
        module.exports = function (deployer) {
          deployer.deploy(EHRRecords);
        };
        